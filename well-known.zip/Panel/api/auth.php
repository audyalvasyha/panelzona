<?php
$db_host = 'localhost'; // Server Name
$db_user = 'szhniszp'; // Username
$db_pass = '2PqE72dtayBHv4vYR54V'; // Password
$db_name = 'szhniszp_AfrizalKeyVvipZona'; // Database Name

$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
if (!$conn) {
	die ('Failed to connect to MySQL: ' . mysqli_connect_error());	
}
?>