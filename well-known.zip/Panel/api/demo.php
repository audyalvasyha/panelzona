<?php

require '../mainconfig.php';
require("auth.php");
date_default_timezone_set('Asia/Jakarta');
if (isset($_POST['id'])) {
  $id = $_POST['id'];
  $server = $_POST['server'];
  $dm = $_POST['dm'];
  $dmharga = $_POST['dmharga'];
  $metode = $_POST['metode'];
  

  if ($dm == "") {
    $_SESSION['pesan'] = "Harus di isi";
    $error = 'is-invalid';
      unset($_SESSION['pesan']);
      // ngecek id game



  } elseif(strlen($id) < 3 OR strlen($id) > 12) {
    
      $validid = "is-invalid";

  }else {
    $error = "";


 
// REDIRECT TO WA
  $nomor = $data->nowa;



  $send = "https://wa.me/$nomor?text=HALO ADMIN%0A%0A*INFO ORDER TOP UP*%0AGAME : MOBILE LEGEND %0A%0A ID GAME+:++ $id  %0A ID SERVER +:++ $server %0A ITEM +:++ $dm %0A HARGA +:++ $dmharga %0A METODE PEMBAYARAN +:++ $metode";



  }
  








} else {
  $error = "";
  $validid = "";
}


 ?>
    
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500&display=swap" rel="stylesheet">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
      <link rel="stylesheet" href="style.css">
      <!-- App favicon -->
      <title><?php echo $rows['name'];?></title>
    </head>
    <body>
        <div class="profile-container">
         <div class="img-container">
            <img src="img/ikuza.jpg" alt="profile image">
         </div>
         <p class="info full-name"><?php echo $rows['name'];?></p>
       

          <div class="posts-info">
             <p><span>Safe</span> <?php echo $rows['game1'] ?></p>
             <p><span>Safe</span> <?php echo $rows['game2'] ?></p>
             <p><span>Safe</span> <?php echo $rows['game3']?></p>
          </div>
        
          <p class="info place">
            <i class="fas fa-star"></i>ORDER <i class="fas fa-star"></i>
         </p>

         <div class="social-container">
             <button onclick=<?php echo "location"."."."href='".$rows['url_yt']."'";?> class="youtube">
                 <i class="fab fa-youtube"></i>
             </button>
             <button onclick=<?php echo "location"."."."href='".$rows['url_tele']."'";?> class="linkedin">
                 <i class="fab fa-telegram"></i>
             </button>
             <button onclick=<?php echo "location"."."."href='".$rows['url_wa']."'";?> class="github">
                 <i class="fab fa-whatsapp"></i>
             </button>
         </div>
         <button href="javascript:;" onclick="modal_open('edit', '<?php echo $config['web']['base_url'] ?>admin/news/lib/edit.php?id=1')" class="action message">Info</button>
     </div>
    <script>
    $(document).ready(function() {
        $('#datatable').DataTable( {
            "order": [[0, 'desc']],
            "processing": true,
            "serverSide": true,
            "columnDefs": [
                { "targets": [3], "orderable": false, "searchable": false } // action
                ],
                "ajax": "<?php echo $config['web']['base_url'] ?>admin/news/ajax_table.php"
            
        });
        
    });
    </script>
    
    </body>
    </html>