<?php
require '../../mainconfig.php';
require '../../lib/check_session.php';

if ($_GET) {
    $model->db_update($db, "token", array('serial' => 0), "id = '".$_GET['id']."'");
    
} 

?>
<div id="modal-result" class="row"></div>
<form class="form-horizontal" method="POST" id="form">
	DATA SUDAH DI RESET </br>
	REFRESH PAGE UNTUK MELIHAT HASIL
</form>