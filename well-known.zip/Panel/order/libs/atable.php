<?php
// query list for paging
if (isset($_POST['delete'])) {
	$check_data = $model->db_query($db, "*", "token", "id = '".$_POST['id']."'");
	if ($check_data['count'] == 0) {
		$_SESSION['result'] = array('alert' => 'danger', 'title' => 'Gagal!', 'msg' => 'Data tidak ditemukan.');
	} else {
		if ($model->db_update($db, "token", array('serial' => 0), "id = '".$_POST['id']."'");) == true) {
			$_SESSION['result'] = array('alert' => 'success', 'title' => 'Berhasil!', 'msg' => 'reset data berhasil.');
		} else {
			$_SESSION['result'] = array('alert' => 'danger', 'title' => 'Gagal!', 'msg' => 'reset data gagal.');
		}
	}
}