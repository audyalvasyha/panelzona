<?php
require '../../mainconfig.php';
require '../../lib/check_session.php';
?>
<div id="modal-result" class="row"></div>
<form class="form-horizontal" method="POST" id="form">
	REFRESH PAGE FOR SEE RESULT
</form>