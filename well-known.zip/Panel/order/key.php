<?php
require '../mainconfig.php';
require '../lib/check_session.php';
// query list for paging
if (isset($_POST['id'])) {
    if (isset($_POST['day'])) {
        $dbs = $model->db_query($db, "*", "token", "id = '".$_POST['id']."'");
        $kalkulasi = $dbs['rows']['durasi'] + $_POST['day'];
        $date1 = $dbs['rows']['start'];
        $date2 = date_create($date1);
        $inter = date_interval_create_from_date_string($kalkulasi." days");
        $add = date_add($date2,$inter);
        $date = date_format($add,'Y-m-d H:i:s');
        $model->db_update($db, "token", array('durasi' =>$kalkulasi, 'cheat_exp' =>$date), "id = '".$_POST['id']."'");
    }
    
}
if ($_GET) {
	if (!empty($_GET['search']) AND !empty($_GET['status'])) {
		$query_list = "SELECT * FROM token WHERE uid = '".$_SESSION['login']."' AND access_key LIKE '%".protect_input($_GET['search'])."%' AND games LIKE '%".protect_input($_GET['status'])."%' ORDER BY id DESC"; // edit
	} else if (!empty($_GET['search'])) {
		$query_list = "SELECT * FROM token WHERE uid = '".$_SESSION['login']."' AND access_key LIKE '%".protect_input($_GET['search'])."%' ORDER BY id DESC"; // edit
	} else if (!empty($_GET['status'])) {
		$query_list = "SELECT * FROM token WHERE uid = '".$_SESSION['login']."' AND games LIKE '%".protect_input($_GET['status'])."%' ORDER BY id DESC"; // edit		
	} else {
		$query_list = "SELECT * FROM token WHERE uid = '".$_SESSION['login']."' ORDER BY id DESC"; // edit
	}
} else {
	$query_list = "SELECT * FROM token WHERE uid = '".$_SESSION['login']."' ORDER BY id DESC"; // edit
}
$records_per_page = 30; // edit

$starting_position = 0;
if(isset($_GET["page"])) {
	$starting_position = ($_GET["page"]-1) * $records_per_page;
}
$new_query = $query_list." LIMIT $starting_position, $records_per_page";
$new_query = mysqli_query($db, $new_query); 
// 
require '../lib/header.php';
?>
						<div class="row">
							<div class="col-lg-12">
                    			<div class="card-box">
                        		<h4 class="m-t-0 m-b-30 header-title"><i class="fa fa-history"></i> Key List</h4>
									<form method="get" action="<?php echo $_SERVER['PHP_SELF']; ?>">
										<div class="row">
										    <div class="form-group col-lg-5">
                                        		<label>Filter Game</label>
                                        		<select class="form-control" name="status">
                                        			<option value="">Semua</option>
                                                   	<option value="MLBB" >MLBB</option>
                                                    <option value="CODM" >CODM</option>
                                                    <option value="PUBGM" >PUBGM</option>
                                        		</select>
                                        	</div>
                                        	<div class="form-group col-lg-5">
                                        		<label>Access Key</label>
                                        		<input type="text" class="form-control" name="search" placeholder="Kata Kunci..." value="">
                                        	</div>
                                        	<div class="form-group col-lg-2">
                                        		<label>Submit</label>
                                        		<button type="submit" class="btn btn-block btn-dark">Filter</button>
                                        	</div>
                                        </div>
								    </form>
									<div class="table-responsive">
                                        <table class="table table-bordered table-hover">
											<thead>
												<tr>
													<th>ID</th>
													<th>NAMA</th>
													<th style="max-width: 100px;">TOKEN</th>
													<th>DURASI</th>
													<th>DEVICE</th>
													<th>GAME</th>
												</tr>
											</thead>
											<?php	
											while ($data_query = mysqli_fetch_assoc($new_query)) {
											$time1 = new DateTime(date("Y-m-d H:i:s"));
											$time2 = new DateTime($data_query['cheat_exp']);
											$interval = $time1->diff($time2)->format("%r%a");
											$jam = $time1->diff($time2)->format("%r%h");
											$sisa = "$interval hari $jam jam";
											if($data_query['serial'] == 0) {
											    $serial = 'BELUM LOGIN';
											}else{
											    $serial = $data_query['serial'];
											}
											if($data_query['active'] == 0){
											    $dur = 'BELUM BERJALAN';
											}else{
											    $dur = $sisa;
											}
											?>
											<tbody>
												<tr>
													<td><a href="javascript:;" onclick="modal_open('detail', '<?php echo $config['web']['base_url']; ?>order/detail/sosmed1.php?T_id=<?php echo $data_query['id'] ?>')" class="badge badge-info">#<?php echo $data_query['id']; ?></a></td>
													<td><?php echo $data_query['data'] ?></td>
													<td><?php echo $data_query['access_key'] ?></td>
													<td><?php echo $dur ?></td>
													<td><?php echo $serial ?></td>
													<td><span class="badge badge-info"><?php echo $data_query['games'] ?></span></td>
												</tr>
                                            </tbody>
											<?php
											}
											?>
										</table>
										<?php
                                        require '../lib/pagination.php';
                                        ?>
										</div>
									</div>
								</div>
							</div>
						</div>
<?php
require '../lib/footer.php';
?>