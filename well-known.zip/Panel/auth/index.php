<?php

require '../mainconfig.php';
require("auth.php");
session_start();
//penting
$mod = $model->db_query($db, "*", "mod_data", "id = '1' AND status = '1'");
date_default_timezone_set('Asia/Jakarta');
if($_POST['key']){
    $cek = $model->db_query($db, "*", "token", "access_key = '" .$_POST['key']."'");
    if($cek['count'] == 0){
        $msg = 'Key not found!!';
    }else{
        if($cek['rows']['active'] != 0){
            if(date('Y-m-d H:i:s') > $cek['rows']['cheat_exp']){
                $msg = 'Key EXPIRED!!!!';
            }else{
                $_SESSION['login'] = $cek['rows']['id'];
                header("Location: ".$config['web']['base_url']."client/");
            }
        }else{
            $_SESSION['login'] = $cek['rows']['id'];
            header("Location: ".$config['web']['base_url']."client/");
        }
        
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
        <link rel="stylesheet" href="stle.css">
        <!-- App favicon -->
        <title>Login Member</title>
        <style type="text/css">.hide{display:none!important}.show{display:block!important}</style>
        <style>
        input[type=text], select {
            width: 100%;
            padding: 12px 20px;
            margin: 8px 0;
            display: inline-block;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            
        }
        input[type=submit] {
            width: 100%;
            background-color: #4CAF50;
            color: white;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            
        }
        input[type=submit]:hover {
            background-color: #45a049;
            }
        </style>
    </head>
    <body>
        <div class="card">
            <div class="cover-photo">
                <img src="../../img/Afrizal.png" class="profile">
            </div>
            <h3 class="profile-name">Client Login</h3>
            <h3 class="profile-name"></h3>
            <form action="" method="post">
            <input class="input" type="text" name="key" id="key" placeholder="Input Your Key">
            <button type="submit" class="btn">Login</button>
            </form>
            <p class="about"><?php echo $msg ?></p>
        </div>
        <script>
        function myFunction() {
            // Get the text field
            var copyText = document.getElementById("myInput");
            // Select the text field
            copyText.select();
            copyText.setSelectionRange(0, 99999); // For mobile devices
            // Copy the text inside the text field
            navigator.clipboard.writeText(copyText.value);
            
        }
        </script>
    </body>
</html>