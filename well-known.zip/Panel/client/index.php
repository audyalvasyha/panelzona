<?php
require '../mainconfig.php';
if (!isset($_SESSION['login'])) {
    exit(header("Location: ".$config['web']['base_url']."auth/"));
    
}else{
    //database
    $cek = $model->db_query($db, "*", "token", "id = '" .$_SESSION['login']."'");
    $dw = $model->db_query($db, "*", "app");
    $d_sell = $model->db_query($db, "*", "users", "id = '" .$cek['rows']['uid']."'");
    $penjual = $d_sell['rows']['username'];
    //waktu
    $time1 = new DateTime(date("Y-m-d H:i:s"));
    $time2 = new DateTime($cek['rows']['cheat_exp']);
    $interval = $time1->diff($time2)->format("%r%a");
    $jam = $time1->diff($time2)->format("%r%h");
    $sisa = "$interval Days $jam Hour";
    //variable
    $isVip = '';
    $durasi = '';
    $serial = '';
    //struktur variable
    if($cek['rows']['vip'] == 1){
        $isVip = 'VIP Client';
        $downloads = $dw['rows']['url'];
    }else{
        $isVip = 'FREE Client';
        $downloads = $dw['rows']['purl'];
    }
    if($cek['rows']['serial'] == 0){
        $serial = 'NOT LOGIN YET';
    }else{
        $serial = $cek['rows']['serial'];
    }
    if($cek['rows']['active'] == 0){
        $durasi = 'NOT LOGIN YET';
    }else{
        $durasi = $sisa;
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">


<title>Profile</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" rel="stylesheet">
<style type="text/css">
    	body{
    margin-top:20px;
    color: #1a202c;
    text-align: left;
    background: rgb(14,0,255);
    background: linear-gradient(234deg, rgba(14,0,255,0.3981967787114846) 0%, rgba(255,0,0,0.3169642857142857) 100%);   
}
.main-body {
    padding: 15px;
}
.card {
    box-shadow: 0 1px 3px 0 rgba(0,0,0,.1), 0 1px 2px 0 rgba(0,0,0,.06);
}

.card {
    position: relative;
    display: flex;
    flex-direction: column;
    min-width: 0;
    word-wrap: break-word;
    background-color: #fff;
    background-clip: border-box;
    border: 0 solid rgba(0,0,0,.125);
    border-radius: .25rem;
}

.card-body {
    flex: 1 1 auto;
    min-height: 1px;
    padding: 1rem;
}

.gutters-sm {
    margin-right: -8px;
    margin-left: -8px;
}

.gutters-sm>.col, .gutters-sm>[class*=col-] {
    padding-right: 8px;
    padding-left: 8px;
}
.mb-3, .my-3 {
    margin-bottom: 1rem!important;
}

.bg-gray-300 {
    background-color: #e2e8f0;
}
.h-100 {
    height: 100%!important;
}
.shadow-none {
    box-shadow: none!important;
}

    </style>
</head>
<body>
<div class="container">
<div class="main-body">

<nav aria-label="breadcrumb" class="main-breadcrumb">
</nav>

<div class="row gutters-sm">
<div class="col-md-4 mb-3">
<div class="card">
<div class="card-body">
<div class="d-flex flex-column align-items-center text-center">
<img src="../../img/Afrizal.png" alt="Admin" class="rounded-circle" width="150">
<div class="mt-3">
<p class="text-muted font-size-sm">MOD TYPE:</p>
<button class="btn btn-outline-primary">ImGui</button>
<button class="btn btn-outline-primary">Java</button>
</div>
</div>
</div>
</div>
<div class="card mt-3">
<ul class="list-group list-group-flush">
<li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
<h6 class="mb-0">Your Key</h6>
<span class="text-secondary"><?php echo $cek['rows']['access_key'] ?></span>
</li>
<li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
<h6 class="mb-0">Reseller</h6>
<span class="text-secondary"><?php echo $penjual ?></span>
</li>
<li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
<h6 class="mb-0">Download</h6>
<span class="text-secondary"><button class="btn btn-outline-primary" onclick=<?php echo "location"."."."href='".$downloads."'";?>><?php echo $dw['rows']['name'] ?></button></span>
</li>
</ul>
</div>
</div>
<div class="col-md-8">
<div class="card mb-3">
<div class="card-body">
<div class="row">
<div class="col-sm-3">
<h6 class="mb-0">Name</h6>
</div>
<div class="col-sm-9 text-secondary">
<?php echo $cek['rows']['data'] ?>
</div>
</div>
<hr>
<div class="row">
<div class="col-sm-3">
<h6 class="mb-0">Service</h6>
</div>
<div class="col-sm-9 text-secondary">
<?php echo $isVip ?>
</div>
</div>
<hr>
<div class="row">
<div class="col-sm-3">
<h6 class="mb-0">Game</h6>
</div>
<div class="col-sm-9 text-secondary">
<?php echo $cek['rows']['games'] ?>
</div>
</div>
<hr>
<div class="row">
<div class="col-sm-3">
<h6 class="mb-0">Expired</h6>
</div>
<div class="col-sm-9 text-secondary">
<?php echo $durasi ?>
</div>
</div>
<hr>
<div class="row">
<div class="col-sm-3">
<h6 class="mb-0">Serial</h6>
</div>
<div class="col-sm-9 text-secondary">
<?php echo $serial ?>
 </div>
</div>
<hr>
<div class="row">
<div class="col-sm-12">
</div>
</div>
</div>
</div>
<div class="row gutters-sm">
<div class="col-sm-6 mb-3">
<div class="card h-100">
<div class="card-body">
<h6 class="d-flex align-items-center mb-3"><i class="material-icons text-info mr-2">Java</i>Status</h6>
<small>Bypass</small>
<div class="progress mb-3" style="height: 5px">
<div class="progress-bar bg-primary" role="progressbar" style="width: 80%" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
</div>
</div>
</div>
</div>
<div class="col-sm-6 mb-3">
<div class="card h-100">
<div class="card-body">
<h6 class="d-flex align-items-center mb-3"><i class="material-icons text-info mr-2">ImGui</i>Status</h6>
<small>Bypass</small>
<div class="progress mb-3" style="height: 5px">
<div class="progress-bar bg-primary" role="progressbar" style="width: 80%" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>
<script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript">
	
</script>
</body>
</html>
<?php
}
?>