<?php
require '../../../mainconfig.php';
require '../../../lib/check_session_admin.php';

if (!isset($_GET['id'])) {
	$result_msg = array('alert' => 'danger', 'title' => 'Gagal!', 'msg' => 'Permintaan tidak diterima.');
} else {
	$data_target = $model->db_query($db, "*", "pgen", "id = '".mysqli_real_escape_string($db, $_GET['id'])."'");
	if ($data_target['count'] == 0) {
		$result_msg = array('alert' => 'danger', 'title' => 'Gagal!', 'msg' => 'Data tidak ditemukan.');
		require '../../lib/result.php';
		exit();
	} else {
?>
<div id="modal-result" class="row"></div>
<form class="form-horizontal" method="POST" id="form-add">
	<div class="form-group">
		<input type="hidden" class="form-control" name="id" value="<?php echo $data_target['rows']['id'] ?>" readonly>
	</div>
	<div class="form-group">
		<label>NAME</label>
		<textarea class="form-control" name="nama" rows="1"><?php echo $data_target['rows']['name'] ?></textarea>
		<label>Kata Kata</label>
		<textarea class="form-control" name="word" rows="3"><?php echo $data_target['rows']['say'] ?></textarea>
		<label>Link Server 1</label>
		<textarea class="form-control" name="slink1" rows="1"><?php echo $data_target['rows']['url1'] ?></textarea>
		<label>Link Server 2</label>
		<textarea class="form-control" name="slink2" rows="1"><?php echo $data_target['rows']['url2'] ?></textarea>
		<label>Link Server 3</label>
		<textarea class="form-control" name="slink3" rows="1"><?php echo $data_target['rows']['url3'] ?></textarea>
	</div>
	<div class="form-group text-right">
			<button class="btn btn-danger" type="reset"><i class="fa fa-undo"></i> Reset</button>
			<button class="btn btn-success" name="edit" type="submit"><i class="fa fa-check"></i> Submit</button>
	</div>
</form>
<?php
	}
}
require '../../../lib/result.php';