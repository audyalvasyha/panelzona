<?php
session_start();
if(header("Location: itu.php") && header("Location: ini.php")){
   echo "awokawokawok";
}else{
    echo "awikawik";
}
?>