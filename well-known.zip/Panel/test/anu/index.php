<?php
<script type="text/javascript">
    var go_url = 'https://semawur.com/';
    var api = 'a797dae9d63400494ac9aec5bf0fc9d7055ef0f2';
    var shorten_includ = ["https://syhdnmodderz.my.id/gen-key/free/"];
</script>
<script src='//safelinku.com/js/web-script.js'></script>
?>